package com.hb.day01;

class StuBean {
	private int num;
	private String name;
	private int kor;
	private int eng;
	private int math;
	public void setNum(int num) {
		this.num = num;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public void setMath(int math) {
		this.math = math;
	}

	public int getMath() {
		return math;
	}
	public int getEng() {
		return eng;
	}
	public int getKor() {
		return kor;
	}
	public String getName() {
		return name;
	}
	public int getNum() {
		return num;
	}
}