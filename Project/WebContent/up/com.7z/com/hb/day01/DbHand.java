package com.hb.day01;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

class DbHand {
	void dbCUD(String sql) {
		Statement stmt;
		try {
			stmt = DB.getConn().createStatement();
			stmt.executeQuery(sql);
		} catch (Exception e) {
			System.out.println("�������� Ȯ��");
		}
	}

	ArrayList<StuBean> dbRead(String sql) {
		ArrayList<StuBean> arr = new ArrayList<StuBean>();
		try {
			Statement stmt = DB.getConn().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				StuBean stu = new StuBean();
				stu.setNum(rs.getInt(1));
				stu.setName(rs.getString(2));
				stu.setKor(rs.getInt(3));
				stu.setEng(rs.getInt(4));
				stu.setMath(rs.getInt(5));
				arr.add(stu);
			}
		} catch (Exception e) {
			System.out.println("���ӽ��� : ����̹� �ε�Ȯ��, �ڷ� ���� Ȯ��, Ŀ�ؼ� ���� Ȯ��");
		}
		return arr;
	}
}
